<?php
// Test email sending with detailed debugging

$to = "test@example.com";
$subject = "DonyoDeFamila - Email Verification Code";
$code = "123456";
$username = "TestUser";

$message = "
<html>
<head>
    <title>DonyoDeFamila - Email Verification Code</title>
</head>
<body>
    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
        <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;'>
            <h1>🎓 DonyoDeFamila</h1>
            <p>Student Platform</p>
        </div>
        <div style='background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;'>
            <h2>Welcome, {$username}!</h2>
            <p>Thank you for signing up for DonyoDeFamila Student Platform. To complete your registration, please verify your email address.</p>
            
            <div style='background: white; border: 2px solid #4a90e2; padding: 20px; text-align: center; margin: 20px 0; border-radius: 8px;'>
                <p>Your verification code is:</p>
                <div style='font-size: 32px; font-weight: bold; color: #4a90e2; letter-spacing: 5px;'>{$code}</div>
            </div>
            
            <p>Enter this code on the verification page to activate your account.</p>
            <p><strong>This code will expire in 15 minutes.</strong></p>
            
            <p>If you didn't create an account with DonyoDeFamila, please ignore this email.</p>
        </div>
        <div style='text-align: center; margin-top: 20px; color: #7f8c8d; font-size: 12px;'>
            <p>© 2025 DonyoDeFamila Student Platform. All rights reserved.</p>
            <p>This is an automated email. Please do not reply.</p>
        </div>
    </div>
</body>
</html>
";

$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-type:text/html;charset=UTF-8\r\n";
$headers .= "From: DonyoDeFamila <noreply@donyodefamila.com>\r\n";
$headers .= "Reply-To: noreply@donyodefamila.com\r\n";
$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

echo "Sending email to: " . $to . "\n";
echo "Subject: " . $subject . "\n";
echo "Headers: " . $headers . "\n";
echo "Message: " . substr($message, 0, 100) . "...\n";

$result = mail($to, $subject, $message, $headers);

if ($result) {
    echo "Email sent successfully!\n";
} else {
    echo "Failed to send email!\n";
}

// Also try with additional parameters
echo "\nTrying with additional sendmail parameters...\n";
$result2 = mail($to, $subject, $message, $headers, "-f noreply@donyodefamila.com");

if ($result2) {
    echo "Email sent successfully with additional parameters!\n";
} else {
    echo "Failed to send email with additional parameters!\n";
}
?>