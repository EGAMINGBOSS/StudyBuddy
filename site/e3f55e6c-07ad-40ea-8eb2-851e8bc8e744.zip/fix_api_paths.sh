#!/bin/bash

# Fix the path in all PHP files in the API directory
for file in /var/www/html/api/*.php; do
    if [[ -f "$file" ]]; then
        echo "Fixing $file"
        sudo sed -i "s|require_once '../../backend/auth.php'|require_once '../backend/auth.php'|g" "$file"
        sudo sed -i "s|require_once '../../backend/bible_verse.php'|require_once '../backend/bible_verse.php'|g" "$file"
        sudo sed -i "s|require_once '../../backend/documents.php'|require_once '../backend/documents.php'|g" "$file"
        sudo sed -i "s|require_once '../../backend/chat.php'|require_once '../backend/chat.php'|g" "$file"
        sudo sed -i "s|require_once '../../backend/email_verification.php'|require_once '../backend/email_verification.php'|g" "$file"
    fi
done

echo "All API files have been updated with correct paths."