<?php
// Test mail function
$to = "test@example.com";
$subject = "Test Email";
$message = "This is a test email from the DonyoDeFamila platform.";
$headers = "From: noreply@donyodefamila.com";

$result = mail($to, $subject, $message, $headers);

if ($result) {
    echo "Email sent successfully using mail() function";
} else {
    echo "Failed to send email using mail() function";
}
?>