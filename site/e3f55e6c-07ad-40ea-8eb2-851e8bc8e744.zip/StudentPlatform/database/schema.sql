-- Enhanced Database Schema for Student Platform
-- Base authentication from provided system
CREATE DATABASE IF NOT EXISTS student_platform;
USE student_platform;

-- Users table (enhanced from provided authentication system)
CREATE TABLE IF NOT EXISTS users (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    profile_picture VARCHAR(255),
    bio TEXT,
    is_online BOOLEAN DEFAULT FALSE,
    last_seen DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
);

-- Chat sessions for random stranger matching
CREATE TABLE IF NOT EXISTS chat_sessions (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    session_id VARCHAR(100) NOT NULL UNIQUE,
    user1_id INT NOT NULL,
    user2_id INT,
    status ENUM('waiting', 'active', 'ended') DEFAULT 'waiting',
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME,
    FOREIGN KEY (user1_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (user2_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_session (session_id)
);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    sender_id INT NOT NULL,
    message TEXT NOT NULL,
    message_type ENUM('text', 'image', 'file') DEFAULT 'text',
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session (session_id),
    INDEX idx_created (created_at)
);

-- Documents (Word, Excel, PowerPoint files)
CREATE TABLE IF NOT EXISTS documents (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    doc_type ENUM('word', 'excel', 'powerpoint', 'image') NOT NULL,
    content LONGTEXT,
    file_path VARCHAR(255),
    thumbnail VARCHAR(255),
    is_public BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_type (doc_type),
    INDEX idx_updated (updated_at)
);

-- Document sharing
CREATE TABLE IF NOT EXISTS document_shares (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    document_id INT NOT NULL,
    shared_with_user_id INT NOT NULL,
    permission ENUM('view', 'edit') DEFAULT 'view',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE,
    FOREIGN KEY (shared_with_user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_share (document_id, shared_with_user_id)
);

-- Bible verses for daily inspiration
CREATE TABLE IF NOT EXISTS bible_verses (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    verse_text TEXT NOT NULL,
    reference VARCHAR(100) NOT NULL,
    book VARCHAR(50) NOT NULL,
    chapter INT NOT NULL,
    verse INT NOT NULL,
    category VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_reference (reference),
    INDEX idx_category (category)
);

-- User daily verse tracking
CREATE TABLE IF NOT EXISTS user_daily_verses (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    verse_id INT NOT NULL,
    shown_date DATE NOT NULL,
    is_favorited BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verse_id) REFERENCES bible_verses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_date (user_id, shown_date)
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('chat', 'document', 'system', 'verse') DEFAULT 'system',
    is_read BOOLEAN DEFAULT FALSE,
    link VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_read (is_read),
    INDEX idx_created (created_at)
);

-- User preferences
CREATE TABLE IF NOT EXISTS user_preferences (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    theme ENUM('light', 'dark', 'auto') DEFAULT 'light',
    language VARCHAR(10) DEFAULT 'en',
    notifications_enabled BOOLEAN DEFAULT TRUE,
    daily_verse_enabled BOOLEAN DEFAULT TRUE,
    chat_sound_enabled BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample Bible verses
INSERT INTO bible_verses (verse_text, reference, book, chapter, verse, category) VALUES
('For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future.', 'Jeremiah 29:11', 'Jeremiah', 29, 11, 'Hope'),
('I can do all things through Christ who strengthens me.', 'Philippians 4:13', 'Philippians', 4, 13, 'Strength'),
('Trust in the Lord with all your heart and lean not on your own understanding.', 'Proverbs 3:5', 'Proverbs', 3, 5, 'Trust'),
('The Lord is my shepherd; I shall not want.', 'Psalm 23:1', 'Psalms', 23, 1, 'Comfort'),
('Be strong and courageous. Do not be afraid; do not be discouraged, for the Lord your God will be with you wherever you go.', 'Joshua 1:9', 'Joshua', 1, 9, 'Courage'),
('And we know that in all things God works for the good of those who love him.', 'Romans 8:28', 'Romans', 8, 28, 'Faith'),
('Cast all your anxiety on him because he cares for you.', '1 Peter 5:7', '1 Peter', 5, 7, 'Peace'),
('The Lord bless you and keep you; the Lord make his face shine on you and be gracious to you.', 'Numbers 6:24-25', 'Numbers', 6, 24, 'Blessing'),
('Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God.', 'Philippians 4:6', 'Philippians', 4, 6, 'Peace'),
('For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.', 'John 3:16', 'John', 3, 16, 'Love');