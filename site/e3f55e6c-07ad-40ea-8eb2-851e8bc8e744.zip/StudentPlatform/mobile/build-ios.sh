#!/bin/bash

# iOS IPA Build Script for DonyoDeFamila Student Platform
# This script creates an iOS IPA using Cordova

echo "Building iOS IPA for DonyoDeFamila Student Platform..."

# Check if Cordova is installed
if ! command -v cordova &> /dev/null
then
    echo "Cordova is not installed. Installing..."
    npm install -g cordova
fi

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "iOS builds require macOS. Creating configuration files only..."
fi

# Create Cordova project
echo "Creating Cordova project..."
cordova create DonyoDeFamilaApp com.donyodefamila.studentplatform DonyoDeFamila

# Copy web files to Cordova www directory
echo "Copying web files..."
cp -r ../frontend/* DonyoDeFamilaApp/www/

# Copy manifest and service worker
cp manifest.json DonyoDeFamilaApp/www/
cp service-worker.js DonyoDeFamilaApp/www/

# Navigate to Cordova project
cd DonyoDeFamilaApp

# Add iOS platform (only on macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "Adding iOS platform..."
    cordova platform add ios
    
    # Add required plugins
    echo "Adding Cordova plugins..."
    cordova plugin add cordova-plugin-whitelist
    cordova plugin add cordova-plugin-splashscreen
    cordova plugin add cordova-plugin-statusbar
    cordova plugin add cordova-plugin-device
    cordova plugin add cordova-plugin-network-information
    cordova plugin add cordova-plugin-camera
    cordova plugin add cordova-plugin-file
    cordova plugin add cordova-plugin-file-transfer
fi

# Update config.xml
cat > config.xml << 'EOF'
<?xml version='1.0' encoding='utf-8'?>
<widget id="com.donyodefamila.studentplatform" version="1.0.0" xmlns="http://www.w3.org/ns/widgets" xmlns:cdv="http://cordova.apache.org/ns/1.0">
    <name>DonyoDeFamila</name>
    <description>
        Complete student platform with chat, office suite, and more
    </description>
    <author email="support@donyodefamila.com" href="https://www.donyodefamila.com">
        DonyoDeFamila Team
    </author>
    <content src="index.html" />
    <access origin="*" />
    <allow-intent href="http://*/*" />
    <allow-intent href="https://*/*" />
    <allow-intent href="tel:*" />
    <allow-intent href="sms:*" />
    <allow-intent href="mailto:*" />
    <allow-intent href="geo:*" />
    <platform name="ios">
        <allow-intent href="itms:*" />
        <allow-intent href="itms-apps:*" />
        <icon height="57" src="res/icon/ios/icon.png" width="57" />
        <icon height="114" src="res/icon/ios/icon@2x.png" width="114" />
        <icon height="40" src="res/icon/ios/icon-40.png" width="40" />
        <icon height="80" src="res/icon/ios/icon-40@2x.png" width="80" />
        <icon height="50" src="res/icon/ios/icon-50.png" width="50" />
        <icon height="100" src="res/icon/ios/icon-50@2x.png" width="100" />
        <icon height="60" src="res/icon/ios/icon-60.png" width="60" />
        <icon height="120" src="res/icon/ios/icon-60@2x.png" width="120" />
        <icon height="180" src="res/icon/ios/icon-60@3x.png" width="180" />
        <icon height="72" src="res/icon/ios/icon-72.png" width="72" />
        <icon height="144" src="res/icon/ios/icon-72@2x.png" width="144" />
        <icon height="76" src="res/icon/ios/icon-76.png" width="76" />
        <icon height="152" src="res/icon/ios/icon-76@2x.png" width="152" />
        <icon height="167" src="res/icon/ios/icon-83.5@2x.png" width="167" />
        <icon height="29" src="res/icon/ios/icon-small.png" width="29" />
        <icon height="58" src="res/icon/ios/icon-small@2x.png" width="58" />
        <icon height="87" src="res/icon/ios/icon-small@3x.png" width="87" />
    </platform>
    <preference name="Orientation" value="portrait" />
    <preference name="StatusBarOverlaysWebView" value="false" />
    <preference name="StatusBarBackgroundColor" value="#4a90e2" />
</widget>
EOF

# Build IPA (only on macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "Building iOS IPA..."
    cordova build ios --release
    
    echo "iOS IPA build complete!"
    echo "IPA location: DonyoDeFamilaApp/platforms/ios/build/device/"
    echo ""
    echo "To sign and distribute the IPA:"
    echo "1. Open the project in Xcode: platforms/ios/DonyoDeFamila.xcodeproj"
    echo "2. Configure signing with your Apple Developer account"
    echo "3. Archive the app (Product > Archive)"
    echo "4. Export the IPA for distribution"
else
    echo "Configuration files created. Build on macOS to generate IPA."
fi