#!/bin/bash

# Android APK Build Script for DonyoDeFamila Student Platform
# This script creates an Android APK using Cordova

echo "Building Android APK for DonyoDeFamila Student Platform..."

# Check if Cordova is installed
if ! command -v cordova &> /dev/null
then
    echo "Cordova is not installed. Installing..."
    npm install -g cordova
fi

# Create Cordova project
echo "Creating Cordova project..."
cordova create DonyoDeFamilaApp com.donyodefamila.studentplatform DonyoDeFamila

# Copy web files to Cordova www directory
echo "Copying web files..."
cp -r ../frontend/* DonyoDeFamilaApp/www/

# Copy manifest and service worker
cp manifest.json DonyoDeFamilaApp/www/
cp service-worker.js DonyoDeFamilaApp/www/

# Navigate to Cordova project
cd DonyoDeFamilaApp

# Add Android platform
echo "Adding Android platform..."
cordova platform add android

# Add required plugins
echo "Adding Cordova plugins..."
cordova plugin add cordova-plugin-whitelist
cordova plugin add cordova-plugin-splashscreen
cordova plugin add cordova-plugin-statusbar
cordova plugin add cordova-plugin-device
cordova plugin add cordova-plugin-network-information
cordova plugin add cordova-plugin-camera
cordova plugin add cordova-plugin-file
cordova plugin add cordova-plugin-file-transfer

# Update config.xml
cat > config.xml << 'EOF'
<?xml version='1.0' encoding='utf-8'?>
<widget id="com.donyodefamila.studentplatform" version="1.0.0" xmlns="http://www.w3.org/ns/widgets" xmlns:cdv="http://cordova.apache.org/ns/1.0">
    <name>DonyoDeFamila</name>
    <description>
        Complete student platform with chat, office suite, and more
    </description>
    <author email="support@donyodefamila.com" href="https://www.donyodefamila.com">
        DonyoDeFamila Team
    </author>
    <content src="index.html" />
    <access origin="*" />
    <allow-intent href="http://*/*" />
    <allow-intent href="https://*/*" />
    <allow-intent href="tel:*" />
    <allow-intent href="sms:*" />
    <allow-intent href="mailto:*" />
    <allow-intent href="geo:*" />
    <platform name="android">
        <allow-intent href="market:*" />
        <icon density="ldpi" src="res/icon/android/ldpi.png" />
        <icon density="mdpi" src="res/icon/android/mdpi.png" />
        <icon density="hdpi" src="res/icon/android/hdpi.png" />
        <icon density="xhdpi" src="res/icon/android/xhdpi.png" />
        <icon density="xxhdpi" src="res/icon/android/xxhdpi.png" />
        <icon density="xxxhdpi" src="res/icon/android/xxxhdpi.png" />
    </platform>
    <preference name="Orientation" value="portrait" />
    <preference name="StatusBarOverlaysWebView" value="false" />
    <preference name="StatusBarBackgroundColor" value="#4a90e2" />
</widget>
EOF

# Build APK
echo "Building Android APK..."
cordova build android --release

echo "Android APK build complete!"
echo "APK location: DonyoDeFamilaApp/platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk"
echo ""
echo "To sign the APK, use:"
echo "jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.keystore app-release-unsigned.apk alias_name"
echo "zipalign -v 4 app-release-unsigned.apk DonyoDeFamila.apk"