<?php
require_once '../../backend/auth.php';

header('Content-Type: application/json');

$auth = new Auth();

if ($auth->isLoggedIn()) {
    echo json_encode([
        'success' => true,
        'user' => $auth->getCurrentUser()
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated'
    ]);
}
?>