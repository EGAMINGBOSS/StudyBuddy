<?php
require_once '../../backend/auth.php';
require_once '../../backend/email_verification.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['user_id']) || !isset($data['email']) || !isset($data['username'])) {
        echo json_encode(['success' => false, 'message' => 'User ID, email, and username are required']);
        exit;
    }
    
    $emailVerification = new EmailVerification();
    $result = $emailVerification->resendVerificationCode($data['user_id'], $data['email'], $data['username']);
    
    echo json_encode($result);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>