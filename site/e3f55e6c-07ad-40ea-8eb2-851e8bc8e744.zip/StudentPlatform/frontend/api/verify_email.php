<?php
require_once '../../backend/auth.php';
require_once '../../backend/email_verification.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['user_id']) || !isset($data['code'])) {
        echo json_encode(['success' => false, 'message' => 'User ID and code are required']);
        exit;
    }
    
    $emailVerification = new EmailVerification();
    $result = $emailVerification->verifyCode($data['user_id'], $data['code']);
    
    echo json_encode($result);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>