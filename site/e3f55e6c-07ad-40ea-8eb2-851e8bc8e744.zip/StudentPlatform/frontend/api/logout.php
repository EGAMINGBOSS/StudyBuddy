<?php
require_once '../../backend/auth.php';

header('Content-Type: application/json');

$auth = new Auth();
$result = $auth->logout();

echo json_encode($result);
?>