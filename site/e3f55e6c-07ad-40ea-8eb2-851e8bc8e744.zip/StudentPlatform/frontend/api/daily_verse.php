<?php
require_once '../../backend/auth.php';
require_once '../../backend/bible_verse.php';

header('Content-Type: application/json');

$auth = new Auth();

if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user = $auth->getCurrentUser();
$bibleVerse = new BibleVerse();
$result = $bibleVerse->getDailyVerse($user['id']);

echo json_encode($result);
?>