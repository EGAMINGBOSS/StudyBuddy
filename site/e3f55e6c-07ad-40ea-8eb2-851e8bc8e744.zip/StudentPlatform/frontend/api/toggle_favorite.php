<?php
require_once '../../backend/auth.php';
require_once '../../backend/bible_verse.php';

header('Content-Type: application/json');

$auth = new Auth();

if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user = $auth->getCurrentUser();
    
    $bibleVerse = new BibleVerse();
    $result = $bibleVerse->toggleFavorite($user['id'], $data['verse_id']);
    
    echo json_encode($result);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>