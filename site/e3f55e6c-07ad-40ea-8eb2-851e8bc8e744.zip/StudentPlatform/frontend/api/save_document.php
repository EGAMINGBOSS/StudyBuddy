<?php
require_once '../../backend/auth.php';
require_once '../../backend/documents.php';

header('Content-Type: application/json');

$auth = new Auth();

if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user = $auth->getCurrentUser();
    
    $documents = new Documents();
    
    if (isset($data['document_id']) && $data['document_id']) {
        // Update existing document
        $result = $documents->updateDocument(
            $data['document_id'],
            $user['id'],
            $data['content'],
            $data['title']
        );
    } else {
        // Create new document
        $result = $documents->createDocument(
            $user['id'],
            $data['title'],
            $data['doc_type'],
            $data['content']
        );
    }
    
    echo json_encode($result);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>