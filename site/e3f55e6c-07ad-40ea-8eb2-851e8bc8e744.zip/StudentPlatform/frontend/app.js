// Main Application JavaScript
let currentUser = null;
let socket = null;
let currentSession = null;
let currentDocumentId = null;

// Initialize app
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    initializeNavigation();
    initializeEditors();
    loadDailyVerse();
    connectWebSocket();
});

// Check authentication
async function checkAuth() {
    try {
        const response = await fetch('api/check_auth.php');
        const data = await response.json();
        
        if (!data.success || !data.user) {
            window.location.href = 'login.html';
            return;
        }
        
        currentUser = data.user;
        updateUserInfo();
    } catch (error) {
        console.error('Auth check failed:', error);
        window.location.href = 'login.html';
    }
}

// Update user info in sidebar
function updateUserInfo() {
    document.getElementById('userName').textContent = currentUser.full_name || currentUser.username;
    document.getElementById('userEmail').textContent = currentUser.email;
    document.getElementById('userAvatar').textContent = currentUser.username.charAt(0).toUpperCase();
}

// Navigation
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const featureCards = document.querySelectorAll('.feature-card');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.getAttribute('data-page');
            if (page) {
                navigateToPage(page);
                
                // Update active state
                navLinks.forEach(l => l.classList.remove('active'));
                link.classList.add('active');
            }
        });
    });
    
    featureCards.forEach(card => {
        card.addEventListener('click', () => {
            const page = card.getAttribute('data-page');
            if (page) {
                navigateToPage(page);
                
                // Update nav active state
                navLinks.forEach(l => l.classList.remove('active'));
                const targetLink = document.querySelector(`[data-page="${page}"]`);
                if (targetLink) targetLink.classList.add('active');
            }
        });
    });
    
    // Logout
    document.getElementById('logoutBtn').addEventListener('click', async (e) => {
        e.preventDefault();
        await fetch('api/logout.php');
        window.location.href = 'login.html';
    });
}

// Navigate to page
function navigateToPage(page) {
    const pages = document.querySelectorAll('.page-content');
    pages.forEach(p => p.classList.add('hidden'));
    
    const targetPage = document.getElementById(`${page}Page`);
    if (targetPage) {
        targetPage.classList.remove('hidden');
        
        // Load page-specific data
        if (page === 'documents') loadDocuments();
        if (page === 'bible') loadFavoriteVerses();
        if (page === 'profile') loadProfile();
    }
}

// Daily Bible Verse
async function loadDailyVerse() {
    try {
        const response = await fetch('api/daily_verse.php');
        const data = await response.json();
        
        if (data.success && data.verse) {
            document.getElementById('verseText').textContent = data.verse.verse_text;
            document.getElementById('verseReference').textContent = `- ${data.verse.reference}`;
            
            // Update favorite button
            const favoriteBtn = document.getElementById('favoriteVerseBtn');
            if (data.verse.is_favorited) {
                favoriteBtn.innerHTML = '<i class="fas fa-heart"></i> Favorited';
            }
            
            favoriteBtn.onclick = () => toggleFavoriteVerse(data.verse.id);
        }
    } catch (error) {
        console.error('Failed to load daily verse:', error);
    }
}

async function toggleFavoriteVerse(verseId) {
    try {
        const response = await fetch('api/toggle_favorite.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ verse_id: verseId })
        });
        
        const data = await response.json();
        if (data.success) {
            loadDailyVerse();
        }
    } catch (error) {
        console.error('Failed to toggle favorite:', error);
    }
}

// WebSocket Connection
function connectWebSocket() {
    socket = io('http://localhost:3000');
    
    socket.on('connect', () => {
        console.log('Connected to WebSocket server');
        socket.emit('user_join', currentUser.id);
    });
    
    socket.on('stranger_found', (data) => {
        currentSession = data.sessionId;
        document.getElementById('chatStatus').textContent = 'Connected to stranger';
        document.getElementById('chatInfo').textContent = 'Chat is active';
        document.getElementById('findStrangerBtn').classList.add('hidden');
        document.getElementById('shuffleBtn').classList.remove('hidden');
        document.getElementById('endChatBtn').classList.remove('hidden');
        document.getElementById('chatInput').disabled = false;
        document.getElementById('sendMessageBtn').disabled = false;
        
        socket.emit('join_session', data.sessionId);
        loadChatMessages(data.sessionId);
    });
    
    socket.on('waiting_for_stranger', (data) => {
        currentSession = data.sessionId;
        document.getElementById('chatStatus').textContent = 'Waiting for stranger...';
        document.getElementById('chatInfo').textContent = 'Looking for someone to chat with';
    });
    
    socket.on('new_message', (data) => {
        displayMessage(data);
    });
    
    socket.on('stranger_left', () => {
        document.getElementById('chatStatus').textContent = 'Stranger left the chat';
        document.getElementById('chatInput').disabled = true;
        document.getElementById('sendMessageBtn').disabled = true;
    });
    
    socket.on('session_ended', () => {
        resetChat();
    });
}

// Chat Functions
document.getElementById('findStrangerBtn')?.addEventListener('click', () => {
    socket.emit('find_stranger', currentUser.id);
    document.getElementById('chatMessages').innerHTML = '<div class="text-center p-20"><div class="spinner"></div><p>Finding a stranger...</p></div>';
});

document.getElementById('shuffleBtn')?.addEventListener('click', () => {
    if (currentSession) {
        socket.emit('shuffle', { sessionId: currentSession, userId: currentUser.id });
        document.getElementById('chatMessages').innerHTML = '<div class="text-center p-20"><div class="spinner"></div><p>Finding a new stranger...</p></div>';
    }
});

document.getElementById('endChatBtn')?.addEventListener('click', () => {
    if (currentSession) {
        socket.emit('end_session', currentSession);
        resetChat();
    }
});

document.getElementById('sendMessageBtn')?.addEventListener('click', sendMessage);
document.getElementById('chatInput')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (message && currentSession) {
        socket.emit('send_message', {
            sessionId: currentSession,
            senderId: currentUser.id,
            message: message,
            messageType: 'text'
        });
        
        input.value = '';
    }
}

function displayMessage(data) {
    const messagesContainer = document.getElementById('chatMessages');
    const isSent = data.senderId === currentUser.id;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;
    
    messageDiv.innerHTML = `
        <div class="message-content">
            <div>${data.message}</div>
            <div class="message-time">${new Date(data.timestamp).toLocaleTimeString()}</div>
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

async function loadChatMessages(sessionId) {
    try {
        const response = await fetch(`api/get_messages.php?session_id=${sessionId}`);
        const data = await response.json();
        
        if (data.success && data.messages) {
            const messagesContainer = document.getElementById('chatMessages');
            messagesContainer.innerHTML = '';
            
            data.messages.forEach(msg => {
                displayMessage({
                    senderId: msg.sender_id,
                    message: msg.message,
                    timestamp: msg.created_at
                });
            });
        }
    } catch (error) {
        console.error('Failed to load messages:', error);
    }
}

function resetChat() {
    currentSession = null;
    document.getElementById('chatStatus').textContent = 'Click "Find Stranger" to start';
    document.getElementById('chatInfo').textContent = 'Anonymous chat';
    document.getElementById('findStrangerBtn').classList.remove('hidden');
    document.getElementById('shuffleBtn').classList.add('hidden');
    document.getElementById('endChatBtn').classList.add('hidden');
    document.getElementById('chatInput').disabled = true;
    document.getElementById('sendMessageBtn').disabled = true;
    document.getElementById('chatMessages').innerHTML = '<div class="text-center p-20"><i class="fas fa-comments" style="font-size: 4em; color: #bdc3c7;"></i><p style="color: #7f8c8d; margin-top: 20px;">Start a conversation with a stranger!</p></div>';
}

// Editor Initialization
function initializeEditors() {
    initializeWordEditor();
    initializeExcelEditor();
    initializePowerPointEditor();
    initializeImageEditor();
}

// Word Editor
function initializeWordEditor() {
    const toolbar = document.querySelectorAll('[data-command]');
    toolbar.forEach(btn => {
        btn.addEventListener('click', () => {
            const command = btn.getAttribute('data-command');
            document.execCommand(command, false, null);
        });
    });
    
    document.getElementById('fontSizeSelect')?.addEventListener('change', (e) => {
        document.execCommand('fontSize', false, e.target.value);
    });
    
    document.getElementById('textColorPicker')?.addEventListener('change', (e) => {
        document.execCommand('foreColor', false, e.target.value);
    });
    
    document.getElementById('saveDocBtn')?.addEventListener('click', saveDocument);
    document.getElementById('newDocBtn')?.addEventListener('click', () => {
        document.getElementById('wordContent').innerHTML = '<h1>New Document</h1><p>Start typing...</p>';
        document.getElementById('docTitle').value = '';
        currentDocumentId = null;
    });
}

async function saveDocument() {
    const title = document.getElementById('docTitle').value || 'Untitled Document';
    const content = document.getElementById('wordContent').innerHTML;
    
    try {
        const response = await fetch('api/save_document.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                document_id: currentDocumentId,
                title: title,
                doc_type: 'word',
                content: content
            })
        });
        
        const data = await response.json();
        if (data.success) {
            alert('Document saved successfully!');
            currentDocumentId = data.document_id;
        }
    } catch (error) {
        console.error('Failed to save document:', error);
        alert('Failed to save document');
    }
}

// Excel Editor
function initializeExcelEditor() {
    createExcelGrid(10, 10);
    
    document.getElementById('addRowBtn')?.addEventListener('click', () => addExcelRow());
    document.getElementById('addColBtn')?.addEventListener('click', () => addExcelColumn());
    document.getElementById('saveExcelBtn')?.addEventListener('click', saveExcelDocument);
    document.getElementById('exportCsvBtn')?.addEventListener('click', exportToCSV);
}

function createExcelGrid(rows, cols) {
    const header = document.getElementById('excelHeader');
    const body = document.getElementById('excelBody');
    
    header.innerHTML = '<th></th>';
    for (let i = 0; i < cols; i++) {
        const th = document.createElement('th');
        th.textContent = String.fromCharCode(65 + i);
        header.appendChild(th);
    }
    
    body.innerHTML = '';
    for (let i = 0; i < rows; i++) {
        const tr = document.createElement('tr');
        const th = document.createElement('th');
        th.textContent = i + 1;
        tr.appendChild(th);
        
        for (let j = 0; j < cols; j++) {
            const td = document.createElement('td');
            const input = document.createElement('input');
            input.type = 'text';
            input.setAttribute('data-row', i);
            input.setAttribute('data-col', j);
            td.appendChild(input);
            tr.appendChild(td);
        }
        
        body.appendChild(tr);
    }
}

function addExcelRow() {
    const body = document.getElementById('excelBody');
    const cols = document.querySelectorAll('#excelHeader th').length - 1;
    const rowNum = body.children.length;
    
    const tr = document.createElement('tr');
    const th = document.createElement('th');
    th.textContent = rowNum + 1;
    tr.appendChild(th);
    
    for (let j = 0; j < cols; j++) {
        const td = document.createElement('td');
        const input = document.createElement('input');
        input.type = 'text';
        input.setAttribute('data-row', rowNum);
        input.setAttribute('data-col', j);
        td.appendChild(input);
        tr.appendChild(td);
    }
    
    body.appendChild(tr);
}

function addExcelColumn() {
    const header = document.getElementById('excelHeader');
    const body = document.getElementById('excelBody');
    const colNum = header.children.length - 1;
    
    const th = document.createElement('th');
    th.textContent = String.fromCharCode(65 + colNum);
    header.appendChild(th);
    
    Array.from(body.children).forEach((row, i) => {
        const td = document.createElement('td');
        const input = document.createElement('input');
        input.type = 'text';
        input.setAttribute('data-row', i);
        input.setAttribute('data-col', colNum);
        td.appendChild(input);
        row.appendChild(td);
    });
}

async function saveExcelDocument() {
    const title = document.getElementById('excelTitle').value || 'Untitled Spreadsheet';
    const data = getExcelData();
    
    try {
        const response = await fetch('api/save_document.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                document_id: currentDocumentId,
                title: title,
                doc_type: 'excel',
                content: JSON.stringify(data)
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Spreadsheet saved successfully!');
            currentDocumentId = result.document_id;
        }
    } catch (error) {
        console.error('Failed to save spreadsheet:', error);
        alert('Failed to save spreadsheet');
    }
}

function getExcelData() {
    const inputs = document.querySelectorAll('#excelBody input');
    const data = [];
    
    inputs.forEach(input => {
        const row = parseInt(input.getAttribute('data-row'));
        const col = parseInt(input.getAttribute('data-col'));
        
        if (!data[row]) data[row] = [];
        data[row][col] = input.value;
    });
    
    return data;
}

function exportToCSV() {
    const data = getExcelData();
    let csv = '';
    
    data.forEach(row => {
        csv += row.join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'spreadsheet.csv';
    a.click();
}

// PowerPoint Editor
let slides = [{ content: '<h1>Title Slide</h1><p>Click to edit</p>' }];
let currentSlide = 0;

function initializePowerPointEditor() {
    document.getElementById('addSlideBtn')?.addEventListener('click', addSlide);
    document.getElementById('deleteSlideBtn')?.addEventListener('click', deleteSlide);
    document.getElementById('prevSlideBtn')?.addEventListener('click', () => navigateSlide(-1));
    document.getElementById('nextSlideBtn')?.addEventListener('click', () => navigateSlide(1));
    document.getElementById('savePptBtn')?.addEventListener('click', savePowerPoint);
    
    document.getElementById('slideContent')?.addEventListener('input', () => {
        slides[currentSlide].content = document.getElementById('slideContent').innerHTML;
    });
}

function addSlide() {
    slides.push({ content: '<h1>New Slide</h1><p>Click to edit</p>' });
    updateSlidesPanel();
    currentSlide = slides.length - 1;
    loadSlide(currentSlide);
}

function deleteSlide() {
    if (slides.length > 1) {
        slides.splice(currentSlide, 1);
        if (currentSlide >= slides.length) currentSlide = slides.length - 1;
        updateSlidesPanel();
        loadSlide(currentSlide);
    }
}

function navigateSlide(direction) {
    const newSlide = currentSlide + direction;
    if (newSlide >= 0 && newSlide < slides.length) {
        currentSlide = newSlide;
        loadSlide(currentSlide);
    }
}

function loadSlide(index) {
    document.getElementById('slideContent').innerHTML = slides[index].content;
    
    document.querySelectorAll('.slide-thumbnail').forEach((thumb, i) => {
        thumb.classList.toggle('active', i === index);
    });
}

function updateSlidesPanel() {
    const panel = document.getElementById('slidesPanel');
    panel.innerHTML = '';
    
    slides.forEach((slide, index) => {
        const thumb = document.createElement('div');
        thumb.className = 'slide-thumbnail';
        if (index === currentSlide) thumb.classList.add('active');
        thumb.setAttribute('data-slide', index);
        thumb.innerHTML = `<p>Slide ${index + 1}</p>`;
        thumb.addEventListener('click', () => {
            currentSlide = index;
            loadSlide(index);
        });
        panel.appendChild(thumb);
    });
}

async function savePowerPoint() {
    const title = document.getElementById('pptTitle').value || 'Untitled Presentation';
    
    try {
        const response = await fetch('api/save_document.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                document_id: currentDocumentId,
                title: title,
                doc_type: 'powerpoint',
                content: JSON.stringify(slides)
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Presentation saved successfully!');
            currentDocumentId = result.document_id;
        }
    } catch (error) {
        console.error('Failed to save presentation:', error);
        alert('Failed to save presentation');
    }
}

// Image Editor
let imageCanvas, imageCtx, originalImage;
let filters = { brightness: 100, contrast: 100, saturation: 100, blur: 0 };

function initializeImageEditor() {
    imageCanvas = document.getElementById('imageCanvas');
    imageCtx = imageCanvas.getContext('2d');
    
    document.getElementById('uploadImageBtn')?.addEventListener('click', () => {
        document.getElementById('imageUpload').click();
    });
    
    document.getElementById('imageUpload')?.addEventListener('change', handleImageUpload);
    document.getElementById('saveImageBtn')?.addEventListener('click', saveImage);
    
    // Filter controls
    document.getElementById('brightnessSlider')?.addEventListener('input', (e) => {
        filters.brightness = e.target.value;
        applyFilters();
    });
    
    document.getElementById('contrastSlider')?.addEventListener('input', (e) => {
        filters.contrast = e.target.value;
        applyFilters();
    });
    
    document.getElementById('saturationSlider')?.addEventListener('input', (e) => {
        filters.saturation = e.target.value;
        applyFilters();
    });
    
    document.getElementById('blurSlider')?.addEventListener('input', (e) => {
        filters.blur = e.target.value;
        applyFilters();
    });
    
    document.getElementById('resetFiltersBtn')?.addEventListener('click', resetFilters);
    
    // Filter buttons
    document.querySelectorAll('[data-filter]').forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.getAttribute('data-filter');
            applyPresetFilter(filter);
        });
    });
}

function handleImageUpload(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
                originalImage = img;
                imageCanvas.width = img.width;
                imageCanvas.height = img.height;
                imageCtx.drawImage(img, 0, 0);
                resetFilters();
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(file);
    }
}

function applyFilters() {
    if (!originalImage) return;
    
    imageCtx.filter = `brightness(${filters.brightness}%) contrast(${filters.contrast}%) saturate(${filters.saturation}%) blur(${filters.blur}px)`;
    imageCtx.drawImage(originalImage, 0, 0);
}

function applyPresetFilter(filter) {
    if (!originalImage) return;
    
    switch(filter) {
        case 'grayscale':
            imageCtx.filter = 'grayscale(100%)';
            break;
        case 'sepia':
            imageCtx.filter = 'sepia(100%)';
            break;
        case 'invert':
            imageCtx.filter = 'invert(100%)';
            break;
    }
    
    imageCtx.drawImage(originalImage, 0, 0);
}

function resetFilters() {
    filters = { brightness: 100, contrast: 100, saturation: 100, blur: 0 };
    document.getElementById('brightnessSlider').value = 100;
    document.getElementById('contrastSlider').value = 100;
    document.getElementById('saturationSlider').value = 100;
    document.getElementById('blurSlider').value = 0;
    
    if (originalImage) {
        imageCtx.filter = 'none';
        imageCtx.drawImage(originalImage, 0, 0);
    }
}

function saveImage() {
    if (!imageCanvas) return;
    
    imageCanvas.toBlob((blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'edited-image.png';
        a.click();
    });
}

// Documents Management
async function loadDocuments() {
    try {
        const response = await fetch('api/get_documents.php');
        const data = await response.json();
        
        const container = document.getElementById('documentsList');
        
        if (data.success && data.documents.length > 0) {
            container.innerHTML = '<h2>Your Documents</h2>';
            
            const grid = document.createElement('div');
            grid.className = 'features-grid';
            
            data.documents.forEach(doc => {
                const card = document.createElement('div');
                card.className = 'feature-card';
                card.innerHTML = `
                    <div class="feature-icon">
                        <i class="fas fa-file-${doc.doc_type}"></i>
                    </div>
                    <h3>${doc.title}</h3>
                    <p>Last updated: ${new Date(doc.updated_at).toLocaleDateString()}</p>
                `;
                card.addEventListener('click', () => openDocument(doc));
                grid.appendChild(card);
            });
            
            container.appendChild(grid);
        } else {
            container.innerHTML = '<p class="text-center">No documents yet. Create your first document!</p>';
        }
    } catch (error) {
        console.error('Failed to load documents:', error);
    }
}

function openDocument(doc) {
    currentDocumentId = doc.id;
    
    switch(doc.doc_type) {
        case 'word':
            navigateToPage('word');
            document.getElementById('docTitle').value = doc.title;
            document.getElementById('wordContent').innerHTML = doc.content;
            break;
        case 'excel':
            navigateToPage('excel');
            document.getElementById('excelTitle').value = doc.title;
            // Load Excel data
            break;
        case 'powerpoint':
            navigateToPage('powerpoint');
            document.getElementById('pptTitle').value = doc.title;
            slides = JSON.parse(doc.content);
            updateSlidesPanel();
            loadSlide(0);
            break;
    }
}

// Favorite Verses
async function loadFavoriteVerses() {
    try {
        const response = await fetch('api/get_favorite_verses.php');
        const data = await response.json();
        
        const container = document.getElementById('favoritesContent');
        
        if (data.success && data.verses.length > 0) {
            container.innerHTML = '';
            
            data.verses.forEach(verse => {
                const card = document.createElement('div');
                card.className = 'verse-card';
                card.style.marginBottom = '20px';
                card.innerHTML = `
                    <div class="verse-text">${verse.verse_text}</div>
                    <div class="verse-reference">- ${verse.reference}</div>
                    <div style="margin-top: 10px; color: rgba(255,255,255,0.7);">
                        <small>Saved on ${new Date(verse.shown_date).toLocaleDateString()}</small>
                    </div>
                `;
                container.appendChild(card);
            });
        } else {
            container.innerHTML = '<p class="text-center">No favorite verses yet. Start favoriting verses from your daily inspiration!</p>';
        }
    } catch (error) {
        console.error('Failed to load favorite verses:', error);
    }
}

// Profile
async function loadProfile() {
    document.getElementById('profileUsername').textContent = currentUser.username;
    document.getElementById('profileEmail').textContent = currentUser.email;
    document.getElementById('profileFullName').textContent = currentUser.full_name || 'Not set';
    document.getElementById('profileCreated').textContent = new Date().toLocaleDateString();
}