# 📧 Email Verification System - Complete Guide

## ✅ Email Verification Feature Added!

Your DonyoDeFamila Student Platform now includes a complete email verification system with 6-digit code generation!

---

## 🎯 How It Works

### 1. User Registration Flow
1. User fills out registration form (Full Name, Username, Email, Password)
2. System creates account but marks it as **unverified**
3. System generates a random 6-digit verification code
4. Code is sent to user's email address
5. User is redirected to verification page
6. User enters the 6-digit code
7. System verifies the code
8. Account is marked as **verified**
9. User can now login

### 2. Login Protection
- Users with unverified emails **cannot login**
- System shows message: "Please verify your email before logging in"
- User is redirected to verification page
- After verification, user can login normally

---

## 📧 Email System

### Email Configuration
The system uses PHP's built-in `mail()` function to send verification emails.

### Email Template
The verification email includes:
- **Beautiful HTML design** with gradient header
- **6-digit verification code** in large, bold text
- **15-minute expiration notice**
- **Professional branding** (DonyoDeFamila logo and colors)
- **Responsive design** for mobile devices

### Email Content Example
```
Subject: DonyoDeFamila - Email Verification Code

🎓 DonyoDeFamila
Student Platform

Welcome, [Username]!

Thank you for signing up for DonyoDeFamila Student Platform. 
To complete your registration, please verify your email address.

Your verification code is:
┌─────────┐
│ 123456  │
└─────────┘

Enter this code on the verification page to activate your account.
This code will expire in 15 minutes.
```

---

## 🔐 Security Features

### Code Generation
- **Random 6-digit codes** (000000 to 999999)
- **Unique per user** - each user gets their own code
- **Time-limited** - expires after 15 minutes
- **One-time use** - code becomes invalid after verification

### Database Security
- Codes stored in separate `email_verifications` table
- Old codes automatically deleted when new ones are generated
- Expired codes cannot be used
- Verified status tracked in both tables

### Validation
- Email format validation
- Code format validation (must be 6 digits)
- Expiration time checking
- Already-verified checking
- User existence validation

---

## 📊 Database Schema

### New Table: email_verifications
```sql
CREATE TABLE email_verifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    code VARCHAR(10) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_at DATETIME NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Updated Table: users
```sql
ALTER TABLE users 
ADD COLUMN email_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN email_verified_at DATETIME NULL;
```

---

## 🎨 User Interface

### Verification Page Features
- **Clean, modern design** matching the platform theme
- **Large code input field** with centered text
- **Real-time countdown timer** showing time remaining
- **Resend code button** for expired/lost codes
- **Auto-formatting** - only accepts numbers
- **Visual feedback** - success/error messages
- **Mobile responsive** - works on all devices

### Page Elements
1. **Info Box** - Explains what to do
2. **Code Input** - Large, easy-to-read input field
3. **Verify Button** - Submit the code
4. **Resend Link** - Request new code
5. **Timer** - Shows expiration countdown
6. **Back to Login** - Return to login page

---

## 🔧 API Endpoints

### 1. Register (Modified)
**Endpoint:** `POST /api/register.php`

**Request:**
```json
{
    "username": "john_doe",
    "email": "john@example.com",
    "password": "password123",
    "full_name": "John Doe"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Registration successful. Please check your email for verification code.",
    "user_id": 1,
    "requires_verification": true
}
```

### 2. Verify Email
**Endpoint:** `POST /api/verify_email.php`

**Request:**
```json
{
    "user_id": 1,
    "code": "123456"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Email verified successfully"
}
```

### 3. Resend Verification Code
**Endpoint:** `POST /api/resend_verification.php`

**Request:**
```json
{
    "user_id": 1,
    "email": "john@example.com",
    "username": "john_doe"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Verification code sent to your email"
}
```

### 4. Login (Modified)
**Endpoint:** `POST /api/login.php`

**Request:**
```json
{
    "username": "john_doe",
    "password": "password123"
}
```

**Response (Unverified):**
```json
{
    "success": false,
    "message": "Please verify your email before logging in",
    "requires_verification": true,
    "user_id": 1,
    "email": "john@example.com",
    "username": "john_doe"
}
```

**Response (Verified):**
```json
{
    "success": true,
    "message": "Login successful",
    "user": {
        "id": 1,
        "username": "john_doe",
        "email": "john@example.com",
        "full_name": "John Doe"
    }
}
```

---

## 🧪 Testing the System

### Test Registration Flow
1. Go to registration page
2. Fill in details with a valid email
3. Submit the form
4. Check your email for the 6-digit code
5. Enter the code on verification page
6. Verify successful verification message
7. Try logging in

### Test Code Expiration
1. Register a new account
2. Wait 15 minutes
3. Try to use the expired code
4. Verify error message appears
5. Click "Resend Code"
6. Use the new code

### Test Resend Functionality
1. Register a new account
2. Click "Resend Code" immediately
3. Check email for new code
4. Verify new code works
5. Verify old code doesn't work

### Test Login Protection
1. Register a new account
2. Don't verify email
3. Try to login
4. Verify redirect to verification page
5. Verify the code
6. Try logging in again
7. Verify successful login

---

## 📝 Code Files

### Backend Files
1. **email_verification.php** - Email verification logic
   - Location: `/var/www/html/backend/email_verification.php`
   - Functions: Generate code, send email, verify code, resend code

2. **auth.php** (Updated) - Authentication with verification
   - Location: `/var/www/html/backend/auth.php`
   - Modified: Register and login functions

### Frontend Files
1. **verify_email.html** - Verification page
   - Location: `/var/www/html/verify_email.html`
   - Features: Code input, timer, resend button

2. **register.html** (Updated) - Registration with redirect
   - Location: `/var/www/html/register.html`
   - Modified: Redirects to verification page

3. **login.html** (Updated) - Login with verification check
   - Location: `/var/www/html/login.html`
   - Modified: Handles unverified users

### API Files
1. **verify_email.php** - Verify code endpoint
   - Location: `/var/www/html/api/verify_email.php`

2. **resend_verification.php** - Resend code endpoint
   - Location: `/var/www/html/api/resend_verification.php`

---

## ⚙️ Configuration

### Email Server Setup
The system uses PHP's `mail()` function. For production:

1. **Install and configure sendmail:**
```bash
apt-get install sendmail
service sendmail start
```

2. **Or use SMTP (recommended for production):**
Install PHPMailer:
```bash
composer require phpmailer/phpmailer
```

Update `email_verification.php` to use SMTP:
```php
use PHPMailer\PHPMailer\PHPMailer;

$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'your-email@gmail.com';
$mail->Password = 'your-app-password';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
```

### Email Customization
Edit `email_verification.php` to customize:
- Email subject
- Email template (HTML)
- Sender name and email
- Code length (default: 6 digits)
- Expiration time (default: 15 minutes)

---

## 🎯 Features Summary

✅ **6-digit verification codes** - Easy to type and remember
✅ **Email delivery** - Automatic email sending
✅ **Beautiful email template** - Professional HTML design
✅ **15-minute expiration** - Security through time limits
✅ **Resend functionality** - Request new codes
✅ **Login protection** - Unverified users cannot login
✅ **Real-time countdown** - Visual timer on verification page
✅ **Auto-formatting** - Input validation
✅ **Mobile responsive** - Works on all devices
✅ **Database tracking** - Complete audit trail
✅ **Security features** - One-time use, expiration, validation

---

## 🚀 Usage Instructions

### For Users
1. **Register** with your email address
2. **Check your email** for the 6-digit code
3. **Enter the code** on the verification page
4. **Login** to your account

### For Administrators
1. **Monitor verifications** in the database
2. **Check email delivery** logs
3. **Adjust expiration time** if needed
4. **Customize email template** for branding

---

## 🔍 Troubleshooting

### Emails Not Sending
1. Check sendmail is installed and running
2. Verify PHP mail() function is enabled
3. Check spam/junk folder
4. Consider using SMTP instead

### Code Not Working
1. Check if code has expired (15 minutes)
2. Verify correct user_id is being used
3. Check database for verification record
4. Try resending a new code

### Timer Not Showing
1. Check JavaScript is enabled
2. Verify page loaded completely
3. Check browser console for errors

---

## 📊 Database Queries

### Check Verification Status
```sql
SELECT u.username, u.email, u.email_verified, u.email_verified_at
FROM users u
WHERE u.id = 1;
```

### View Verification Codes
```sql
SELECT ev.*, u.username, u.email
FROM email_verifications ev
JOIN users u ON ev.user_id = u.id
ORDER BY ev.created_at DESC;
```

### Find Expired Codes
```sql
SELECT * FROM email_verifications
WHERE expires_at < NOW() AND verified = FALSE;
```

### Manually Verify User
```sql
UPDATE users 
SET email_verified = TRUE, email_verified_at = NOW() 
WHERE id = 1;
```

---

## 🎊 Success!

Your email verification system is now fully operational!

**Test it now:**
1. Go to: https://80-d855f309-41a9-4652-8eb3-b88da90af8f9.proxy.daytona.works
2. Click "Sign Up"
3. Register with your email
4. Check your email for the code
5. Verify and login!

---

**Made with ❤️ by NinjaTech AI**