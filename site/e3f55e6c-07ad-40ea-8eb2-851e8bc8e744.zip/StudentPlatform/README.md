# DonyoDeFamila Student Platform

A comprehensive web and mobile application for students featuring real-time chat, office suite, image editing, and daily Bible verses.

## Features

### 🎯 Core Features
- **Random Stranger Chat**: Connect with random people worldwide with shuffle functionality
- **MS Word Editor**: Full-featured document editor with formatting tools
- **Excel Editor**: Spreadsheet editor with formulas and CSV export
- **PowerPoint Editor**: Create stunning presentations with multiple slides
- **Image Editor**: Professional photo editing with filters and adjustments
- **Daily Bible Verses**: Get inspired with daily scripture and save favorites
- **Document Management**: Store and organize all your documents
- **Real-time Messaging**: WebSocket-powered instant messaging

### 🔐 Authentication System
- Secure user registration and login
- Password reset functionality
- Session management
- User profiles

### 📱 Mobile Support
- Progressive Web App (PWA)
- Android APK support
- iOS IPA support
- Offline functionality
- Responsive design

## Technology Stack

### Backend
- **PHP 7.4+**: Server-side logic and API
- **MySQL**: Database management
- **Node.js**: WebSocket server for real-time features
- **Socket.io**: Real-time bidirectional communication

### Frontend
- **HTML5/CSS3**: Modern web standards
- **JavaScript (ES6+)**: Interactive functionality
- **Socket.io Client**: Real-time chat
- **Canvas API**: Image editing

### Mobile
- **Apache Cordova**: Mobile app framework
- **PWA**: Progressive Web App capabilities
- **Service Workers**: Offline support

## Installation

### Prerequisites
- Linux server (Ubuntu/Debian recommended)
- Apache 2.4+
- PHP 7.4+
- MySQL 5.7+
- Node.js 14+
- npm

### Quick Setup

1. **Clone or extract the project**
```bash
cd /workspace/StudentPlatform
```

2. **Run the setup script**
```bash
sudo chmod +x setup.sh
sudo ./setup.sh
```

3. **Access the platform**
- Open your browser and navigate to `http://localhost` or `http://your-server-ip`
- Create an account and start using the platform!

### Manual Setup

1. **Install dependencies**
```bash
# System packages
sudo apt-get update
sudo apt-get install -y apache2 php php-mysql mysql-server nodejs npm

# Node.js packages
cd backend
npm install
```

2. **Setup database**
```bash
mysql -u root -p
CREATE DATABASE student_platform;
USE student_platform;
SOURCE database/schema.sql;
```

3. **Configure database connection**
Edit `config/database.php` with your MySQL credentials.

4. **Setup web server**
```bash
# Copy files to web root
sudo cp -r frontend/* /var/www/html/

# Set permissions
sudo chown -R www-data:www-data /var/www/html/
sudo chmod -R 755 /var/www/html/
```

5. **Start WebSocket server**
```bash
cd backend
node server.js
```

## Configuration

### Database Configuration
Edit `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'student_platform');
```

### WebSocket Server
The WebSocket server runs on port 3000 by default. To change:
Edit `backend/server.js`:
```javascript
const PORT = process.env.PORT || 3000;
```

### Custom Domain
To use custom domain (www.DonyoDeFamila.com):

1. Update Apache virtual host in `/etc/apache2/sites-available/donyodefamila.conf`
2. Point your domain DNS to your server IP
3. Restart Apache: `sudo systemctl restart apache2`

## Mobile App Building

### Android APK
```bash
cd mobile
chmod +x build-android.sh
./build-android.sh
```

The APK will be generated in `mobile/DonyoDeFamilaApp/platforms/android/app/build/outputs/apk/release/`

### iOS IPA
```bash
cd mobile
chmod +x build-ios.sh
./build-ios.sh
```

Note: iOS builds require macOS with Xcode installed.

## Usage

### Creating an Account
1. Navigate to the platform URL
2. Click "Sign Up"
3. Fill in your details
4. Login with your credentials

### Using Random Chat
1. Go to "Random Chat" from the dashboard
2. Click "Find Stranger"
3. Start chatting when connected
4. Use "Shuffle" to find a new stranger
5. Click "End Chat" when done

### Creating Documents
1. Select the editor type (Word, Excel, PowerPoint)
2. Create your content
3. Click "Save" and provide a title
4. Access saved documents from "My Documents"

### Image Editing
1. Go to "Image Editor"
2. Upload an image
3. Apply filters and adjustments
4. Save the edited image

### Daily Bible Verses
- View your daily verse on the dashboard
- Click "Favorite" to save verses
- Access favorites from "Bible Verses" page

## API Endpoints

### Authentication
- `POST /api/login.php` - User login
- `POST /api/register.php` - User registration
- `POST /api/logout.php` - User logout
- `GET /api/check_auth.php` - Check authentication status
- `POST /api/reset_password.php` - Reset password

### Documents
- `POST /api/save_document.php` - Save/update document
- `GET /api/get_documents.php` - Get user documents

### Chat
- `GET /api/get_messages.php` - Get chat messages

### Bible Verses
- `GET /api/daily_verse.php` - Get daily verse
- `POST /api/toggle_favorite.php` - Toggle favorite verse
- `GET /api/get_favorite_verses.php` - Get favorite verses

## WebSocket Events

### Client to Server
- `user_join` - User joins with ID
- `find_stranger` - Find random stranger
- `join_session` - Join chat session
- `send_message` - Send message
- `typing` - User typing indicator
- `shuffle` - Find new stranger
- `end_session` - End chat session

### Server to Client
- `stranger_found` - Stranger matched
- `waiting_for_stranger` - Waiting for match
- `new_message` - New message received
- `user_typing` - Stranger typing
- `stranger_left` - Stranger disconnected
- `session_ended` - Session ended

## Troubleshooting

### WebSocket Connection Issues
```bash
# Check if server is running
sudo systemctl status donyodefamila-websocket

# View logs
tail -f /var/log/websocket-server.log

# Restart server
sudo systemctl restart donyodefamila-websocket
```

### Database Connection Issues
```bash
# Check MySQL status
sudo systemctl status mysql

# Test connection
mysql -u student_user -p student_platform
```

### Apache Issues
```bash
# Check Apache status
sudo systemctl status apache2

# View error logs
sudo tail -f /var/log/apache2/error.log

# Restart Apache
sudo systemctl restart apache2
```

## Security Considerations

1. **Change default database credentials** in production
2. **Enable HTTPS** for secure communication
3. **Configure firewall** to allow only necessary ports
4. **Regular updates** of all dependencies
5. **Backup database** regularly
6. **Use strong passwords** for all accounts

## Performance Optimization

1. **Enable PHP OPcache**
2. **Configure MySQL query cache**
3. **Use CDN** for static assets
4. **Enable Gzip compression**
5. **Optimize images** before upload
6. **Use connection pooling** for database

## Contributing

Contributions are welcome! Please follow these guidelines:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions:
- Email: support@donyodefamila.com
- Website: https://www.donyodefamila.com

## Credits

Developed by the DonyoDeFamila Team
Powered by NinjaTech AI

## Version History

### Version 1.0.0 (2025)
- Initial release
- Random stranger chat with shuffle
- Office suite (Word, Excel, PowerPoint)
- Image editor
- Daily Bible verses
- Mobile app support
- Real-time messaging
- Document management

---

**Note**: This platform is designed for educational purposes and student productivity. Please use responsibly and respect other users.