<?php
$to = "test@example.com";
$subject = "Test Email from DonyoDeFamila";
$message = "
<html>
<head>
<title>Test Email</title>
</head>
<body>
<h2>Test Email</h2>
<p>This is a test email from the DonyoDeFamila platform.</p>
</body>
</html>
";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: DonyoDeFamila <noreply@donyodefamila.com>" . "\r\n";

$result = mail($to, $subject, $message, $headers);

if ($result) {
    echo "Email sent successfully";
} else {
    echo "Failed to send email";
}
?>