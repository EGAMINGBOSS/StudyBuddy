<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Include database connection
require_once "config/database.php";

// Define variables and initialize with empty values
$new_password = $confirm_password = "";
$new_password_err = $confirm_password_err = "";
$success_message = $error_message = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Check which form was submitted
    if(isset($_POST["update_password"])) {
        // Validate new password
        if(empty(trim($_POST["new_password"]))) {
            $new_password_err = "Please enter the new password.";     
        } elseif(strlen(trim($_POST["new_password"])) < 6) {
            $new_password_err = "Password must have at least 6 characters.";
        } else {
            $new_password = trim($_POST["new_password"]);
        }
        
        // Validate confirm password
        if(empty(trim($_POST["confirm_password"]))) {
            $confirm_password_err = "Please confirm the password.";
        } else {
            $confirm_password = trim($_POST["confirm_password"]);
            if(empty($new_password_err) && ($new_password != $confirm_password)) {
                $confirm_password_err = "Password did not match.";
            }
        }
        
        // Check input errors before updating the database
        if(empty($new_password_err) && empty($confirm_password_err)) {
            // Prepare an update statement
            $conn = getDBConnection();
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            
            if($stmt = $conn->prepare($sql)) {
                // Set parameters
                $param_password = password_hash($new_password, PASSWORD_DEFAULT);
                $param_id = $_SESSION["id"];
                
                // Bind variables to the prepared statement as parameters
                $stmt->bind_param("si", $param_password, $param_id);
                
                // Attempt to execute the prepared statement
                if($stmt->execute()) {
                    // Password updated successfully. Display success message
                    $success_message = "Your password has been updated successfully.";
                    
                    // Clear the form fields
                    $new_password = $confirm_password = "";
                } else {
                    $error_message = "Oops! Something went wrong. Please try again later.";
                }
                
                // Close statement
                $stmt->close();
            }
            
            // Close connection
            $conn->close();
        }
    } elseif(isset($_POST["update_profile"])) {
        // Handle profile update (full name, etc.)
        $full_name = trim($_POST["full_name"]);
        
        $conn = getDBConnection();
        $sql = "UPDATE users SET full_name = ? WHERE id = ?";
        
        if($stmt = $conn->prepare($sql)) {
            // Set parameters
            $param_full_name = $full_name;
            $param_id = $_SESSION["id"];
            
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("si", $param_full_name, $param_id);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()) {
                // Profile updated successfully. Update session variable and display success message
                $_SESSION["full_name"] = $full_name;
                $success_message = "Your profile has been updated successfully.";
            } else {
                $error_message = "Oops! Something went wrong. Please try again later.";
            }
            
            // Close statement
            $stmt->close();
        }
        
        // Close connection
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Student Platform</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Student Platform</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="welcome.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="https://via.placeholder.com/150" class="profile-img" alt="Profile Picture">
                        <h4><?php echo htmlspecialchars($_SESSION["username"]); ?></h4>
                        <p class="text-muted"><?php echo !empty($_SESSION["full_name"]) ? htmlspecialchars($_SESSION["full_name"]) : "Student"; ?></p>
                        <p class="text-muted"><?php echo htmlspecialchars($_SESSION["email"]); ?></p>
                        <button class="btn btn-outline-primary btn-sm mt-2" data-toggle="modal" data-target="#uploadPhotoModal">
                            <i class="fas fa-camera mr-1"></i> Change Photo
                        </button>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Account Settings</h5>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="#" class="list-group-item list-group-item-action active" data-toggle="tab" data-target="#profile">
                            <i class="fas fa-user mr-2"></i> Profile Information
                        </a>
                        <a href="#" class="list-group-item list-group-item-action" data-toggle="tab" data-target="#security">
                            <i class="fas fa-lock mr-2"></i> Security
                        </a>
                        <a href="#" class="list-group-item list-group-item-action" data-toggle="tab" data-target="#preferences">
                            <i class="fas fa-cog mr-2"></i> Preferences
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <?php 
                if(!empty($success_message)){
                    echo '<div class="alert alert-success">' . $success_message . '</div>';
                }
                if(!empty($error_message)){
                    echo '<div class="alert alert-danger">' . $error_message . '</div>';
                }
                ?>
                
                <div class="tab-content">
                    <!-- Profile Information Tab -->
                    <div class="tab-pane fade show active" id="profile">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Profile Information</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($_SESSION["username"]); ?>" disabled>
                                        <small class="form-text text-muted">Username cannot be changed.</small>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($_SESSION["email"]); ?>" disabled>
                                        <small class="form-text text-muted">Email cannot be changed.</small>
                                    </div>
                                    <div class="form-group">
                                        <label for="full_name">Full Name</label>
                                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo !empty($_SESSION["full_name"]) ? htmlspecialchars($_SESSION["full_name"]) : ""; ?>">
                                    </div>
                                    <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Security Tab -->
                    <div class="tab-pane fade" id="security">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Change Password</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                    <div class="form-group">
                                        <label for="new_password">New Password</label>
                                        <input type="password" name="new_password" id="new_password" class="form-control <?php echo (!empty($new_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $new_password; ?>">
                                        <span class="help-block"><?php echo $new_password_err; ?></span>
                                    </div>
                                    <div class="form-group">
                                        <label for="confirm_password">Confirm Password</label>
                                        <input type="password" name="confirm_password" id="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>">
                                        <span class="help-block"><?php echo $confirm_password_err; ?></span>
                                    </div>
                                    <button type="submit" name="update_password" class="btn btn-primary">Change Password</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Preferences Tab -->
                    <div class="tab-pane fade" id="preferences">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">User Preferences</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="form-group">
                                        <label for="theme">Theme</label>
                                        <select class="form-control" id="theme">
                                            <option value="light" selected>Light</option>
                                            <option value="dark">Dark</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="emailNotifications" checked>
                                            <label class="custom-control-label" for="emailNotifications">Email Notifications</label>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Save Preferences</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Upload Photo Modal -->
    <div class="modal fade" id="uploadPhotoModal" tabindex="-1" role="dialog" aria-labelledby="uploadPhotoModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadPhotoModalLabel">Upload Profile Photo</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="profilePhoto">Select Image</label>
                            <input type="file" class="form-control-file" id="profilePhoto">
                            <small class="form-text text-muted">Max file size: 2MB. Supported formats: JPG, PNG.</small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Upload</button>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light py-3 mt-5">
        <div class="container text-center">
            <p>&copy; <?php echo date("Y"); ?> Student Platform. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
    <script>
        // Handle tab navigation
        $(document).ready(function() {
            $('.list-group-item').on('click', function(e) {
                e.preventDefault();
                $('.list-group-item').removeClass('active');
                $(this).addClass('active');
            });
        });
    </script>
</body>
</html>